class CfgPatches
{
	class OF_Hoodie_Set
	{
		units[]={};
		weapons[]={};
		requiredVersion=0.1;
		requiredAddons[]=
		{
			"DZ_Characters",
			"DZ_Characters_Tops",
			"DZ_Characters_Vests",
			"DZ_Characters_Pants",
		};
	};
};

class CfgVehicles
{
	class Clothing_Base;
	class Hoodie_ColorBase;
	class OF_Barcelona_Hoodie: Hoodie_ColorBase
	{
		displayName="Barcelona Hoodie";
		scope=2;
		descriptionShort="";
		hiddenSelections[]=
		{
			"camoGround",
			"camoMale",
			"camoFemale"
		};
		hiddenSelectionsTextures[]=
		{
			"Fluffie_Customs\Hoodie\data\Barcelona_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Barcelona_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Barcelona_Hoodie.paa"
		};
	};	
	class OF_NBA_Chicagobulls_Hoodie: Hoodie_ColorBase
	{
		displayName="Chicago Bulls Hoodie";
		scope=2;
		descriptionShort="";
		hiddenSelections[]=
		{
			"camoGround",
			"camoMale",
			"camoFemale"
		};
		hiddenSelectionsTextures[]=
		{
			"Fluffie_Customs\Hoodie\data\NBA_Chicagobulls_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\NBA_Chicagobulls_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\NBA_Chicagobulls_Hoodie.paa"
		};
	};	
	class OF_NBA_Goldenstate_Hoodie: Hoodie_ColorBase
	{
		displayName="Golden State Hoodie";
		scope=2;
		descriptionShort="";
		hiddenSelections[]=
		{
			"camoGround",
			"camoMale",
			"camoFemale"
		};
		hiddenSelectionsTextures[]=
		{
			"Fluffie_Customs\Hoodie\data\NBA_Goldenstate_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\NBA_Goldenstate_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\NBA_Goldenstate_Hoodie.paa"
		};
	};
	class OF_Nike_Airmax_Hoodie: Hoodie_ColorBase
	{
		displayName="Nike Airmax Hoodie";
		scope=2;
		descriptionShort="";
		hiddenSelections[]=
		{
			"camoGround",
			"camoMale",
			"camoFemale"
		};
		hiddenSelectionsTextures[]=
		{
			"Fluffie_Customs\Hoodie\data\Nike_Airmax_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Nike_Airmax_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Nike_Airmax_Hoodie.paa"
		};
	};
	class OF_Nike_Graffiti_Hoodie: Hoodie_ColorBase
	{
		displayName="Nike Graffiti Hoodie";
		scope=2;
		descriptionShort="";
		hiddenSelections[]=
		{
			"camoGround",
			"camoMale",
			"camoFemale"
		};
		hiddenSelectionsTextures[]=
		{
			"Fluffie_Customs\Hoodie\data\Nike_Graffiti_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Nike_Graffiti_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Nike_Graffiti_Hoodie.paa"
		};
	};
	class OF_Nike_Ocean_Hoodie: Hoodie_ColorBase
	{
		displayName="Nike Ocean Hoodie";
		scope=2;
		descriptionShort="";
		hiddenSelections[]=
		{
			"camoGround",
			"camoMale",
			"camoFemale"
		};
		hiddenSelectionsTextures[]=
		{
			"Fluffie_Customs\Hoodie\data\Nike_Ocean_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Nike_Ocean_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Nike_Ocean_Hoodie.paa"
		};
	};
	class OF_Nike_Sport_Hoodie: Hoodie_ColorBase
	{
		displayName="Nike Sport Hoodie";
		scope=2;
		descriptionShort="";
		hiddenSelections[]=
		{
			"camoGround",
			"camoMale",
			"camoFemale"
		};
		hiddenSelectionsTextures[]=
		{
			"Fluffie_Customs\Hoodie\data\Nike_Sport_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Nike_Sport_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Nike_Sport_Hoodie.paa"
		};
	};
	class OF_Nike_Surfer_Hoodie: Hoodie_ColorBase
	{
		displayName="Nike Surfer Hoodie";
		scope=2;
		descriptionShort="";
		hiddenSelections[]=
		{
			"camoGround",
			"camoMale",
			"camoFemale"
		};
		hiddenSelectionsTextures[]=
		{
			"Fluffie_Customs\Hoodie\data\Nike_Surfer_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Nike_Surfer_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Nike_Surfer_Hoodie.paa"
		};
	};
	class OF_Prem_Leeds_Hoodie: Hoodie_ColorBase
	{
		displayName="Leeds United Hoodie";
		scope=2;
		descriptionShort="";
		hiddenSelections[]=
		{
			"camoGround",
			"camoMale",
			"camoFemale"
		};
		hiddenSelectionsTextures[]=
		{
			"Fluffie_Customs\Hoodie\data\Prem_Leeds_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Prem_Leeds_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Prem_Leeds_Hoodie.paa"
		};
	};
	class OF_Prem_Wolves_Hoodie: Hoodie_ColorBase
	{
		displayName="Wolves Hoodie";
		scope=2;
		descriptionShort="";
		hiddenSelections[]=
		{
			"camoGround",
			"camoMale",
			"camoFemale"
		};
		hiddenSelectionsTextures[]=
		{
			"Fluffie_Customs\Hoodie\data\Prem_Wolves_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Prem_Wolves_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Prem_Wolves_Hoodie.paa"
		};
	};
	class OF_Razer_Hoodie: Hoodie_ColorBase
	{
		displayName="Razer Hoodie";
		scope=2;
		descriptionShort="";
		hiddenSelections[]=
		{
			"camoGround",
			"camoMale",
			"camoFemale"
		};
		hiddenSelectionsTextures[]=
		{
			"Fluffie_Customs\Hoodie\data\Razer_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Razer_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Razer_Hoodie.paa"
		};
	};
	class OF_Real_Madrid_Hoodie: Hoodie_ColorBase
	{
		displayName="Real Madrid Hoodie";
		scope=2;
		descriptionShort="";
		hiddenSelections[]=
		{
			"camoGround",
			"camoMale",
			"camoFemale"
		};
		hiddenSelectionsTextures[]=
		{
			"Fluffie_Customs\Hoodie\data\Realmadrid_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Realmadrid_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Realmadrid_Hoodie.paa"
		};
	};
	class OF_Air_Jordan_Hoodie: Hoodie_ColorBase
	{
		displayName="Air Jordan Hoodie";
		scope=2;
		descriptionShort="";
		hiddenSelections[]=
		{
			"camoGround",
			"camoMale",
			"camoFemale"
		};
		hiddenSelectionsTextures[]=
		{
			"Fluffie_Customs\Hoodie\data\Air_Jordan_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Air_Jordan_Hoodie.paa",
			"Fluffie_Customs\Hoodie\data\Air_Jordan_Hoodie.paa"
		};
	};
};