class CfgPatches
{
    class Fluffie_Customs
    {
		units[]={};
        weapons[]={};
        requiredVersion=0.1;
        requiredAddons[]={
			"DZ_Data",
			"DZ_Characters",
        };
    };
};
class CfgVehicles
{
    class TTSKOPants;
    class OF_Panda_Pants: TTSKOPants
    {
		scope=2;
        displayName ="Panda's Pants";
        descriptionShort ="";
        		itemSize[] = {2,2};
		itemsCargoSize[] = {10,15};
		varWetMax=0.25;
        heatIsolation=1;
		attachments[] = {"Knife"};
		hiddenSelections[] = 
		{
			"zbytek",
			"zbytek",
			"zbytek"
		};
        hiddenSelectionsTextures[] =
        {
            "Fluffie_Customs\Pandas_Clothing\PandaPants\Panda_Pants.paa",
            "Fluffie_Customs\Pandas_Clothing\PandaPants\Panda_Pants.paa",
            "Fluffie_Customs\Pandas_Clothing\PandaPants\Panda_Pants.paa"
        };
    };
};
