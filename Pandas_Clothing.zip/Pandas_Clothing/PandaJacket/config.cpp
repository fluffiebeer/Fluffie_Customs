class CfgPatches
{
    class Fluffie_Customs
    {
		units[]={};
        weapons[]={};
        requiredVersion=0.1;
        requiredAddons[]={
			"DZ_Data",
			"DZ_Characters",
        };
    };
};
class CfgVehicles
{
    class TacticalShirt_ColorBase;
    class OF_Panda_Jacket: TacticalShirt_ColorBase
    {
		scope=2;
        displayName ="Panda's Jacket";
        descriptionShort ="";
        itemSize[] = {2,2};
		itemsCargoSize[] = {10,15};
		varWetMax=0.25;
        heatIsolation=1;
		attachments[] = {"Pistol","Knife"};
		hiddenSelections[] = 
		{
			"zbytek",
			"zbytek",
			"zbytek"
		};
        hiddenSelectionsTextures[] =
        {
            "Fluffie_Customs\Pandas_Clothing\PandaJacket\Pandas_Admin_Jacket.paa",
            "Fluffie_Customs\Pandas_Clothing\PandaJacket\Pandas_Admin_Jacket.paa",
            "Fluffie_Customs\Pandas_Clothing\PandaJacket\Pandas_Admin_Jacket.paa"
        };
    };
};
