class CfgPatches
{
    class Fluffie_Customs
    {
		units[]={};
        weapons[]={};
        requiredVersion=0.1;
        requiredAddons[]={
			"DZ_Data",
			"DZ_Characters",
        };
    };
};
class CfgVehicles
{
    class AthleticShoes_ColorBase;
    class OF_Test_shoes: AthleticShoes_ColorBase
    {
		scope=2;
        displayName ="testing";
        descriptionShort ="";
        itemSize[] = {2,2};
		itemsCargoSize[] = {};
		varWetMax=0.25;
        heatIsolation=1;
		attachments[] = {};
		hiddenSelections[] = 
		{
			"zbytek",
			"zbytek",
			"zbytek"
		};
        hiddenSelectionsTextures[] =
        {
            "Fluffie_Customs\Fluffies_Clothing\Sneaker\Fluffies_Sneakers.paa",
            "Fluffie_Customs\Fluffies_Clothing\Sneaker\Fluffies_Sneakers.paa",
            "Fluffie_Customs\Fluffies_Clothing\Sneaker\Fluffies_Sneakers.paa"
        };
    };
};
