class CfgPatches
{
    class Fluffie_Customs
    {
		units[]={};
        weapons[]={};
        requiredVersion=0.1;
        requiredAddons[]={
			"DZ_Data",
			"DZ_Characters",
        };
    };
};
class CfgVehicles
{
    class CombatBoots_ColorBase;
    class OF_Test_Boots: CombatBoots_ColorBase
    {
		scope=2;
        displayName ="testing";
        descriptionShort ="";
        itemSize[] = {2,2};
		itemsCargoSize[] = {10,15};
		varWetMax=0.25;
        heatIsolation=1;
		attachments[] = {"Pistol","Knife"};
		hiddenSelections[] = 
		{
			"zbytek",
			"zbytek",
			"zbytek"
		};
        hiddenSelectionsTextures[] =
        {
            "Fluffie_Customs\Fluffies_Clothing\Boots\Fluffies_Combat_Boots.paa",
            "Fluffie_Customs\Fluffies_Clothing\Boots\Fluffies_Combat_Boots.paa",
            "Fluffie_Customs\Fluffies_Clothing\Boots\Fluffies_Combat_Boots.paa"
        };
    };
};
