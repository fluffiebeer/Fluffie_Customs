class CfgPatches
{
    class Fluffie_Customs
    {
		units[]={};
        weapons[]={};
        requiredVersion=0.1;
        requiredAddons[]={
			"DZ_Data",
			"DZ_Characters",
        };
    };
};
class CfgVehicles
{
    class OMNOGloves_ColorBase;
    class OF_Fluffies_Gloves: OMNOGloves_ColorBase
    {
		scope=2;
        displayName ="Fluffie's Admin Gloves";
        descriptionShort ="";
        itemSize[] = {2,2};
		itemsCargoSize[] = {};
		varWetMax=0.25;
        heatIsolation=1;
		attachments[] = {};
		hiddenSelections[] = 
		{
			"zbytek",
			"zbytek",
			"zbytek"
		};
        hiddenSelectionsTextures[] =
        {
            "Fluffie_Customs\Fluffies_Clothing\Gloves\Fluffies_Admin_Gloves.paa",
            "Fluffie_Customs\Fluffies_Clothing\Gloves\Fluffies_Admin_Gloves.paa",
            "Fluffie_Customs\Fluffies_Clothing\Gloves\Fluffies_Admin_Gloves.paa"
        };
    };
};
