class CfgPatches
{
    class Fluffie_Customs
    {
		units[]={};
        weapons[]={};
        requiredVersion=0.1;
        requiredAddons[]={
			"DZ_Data",
			"DZ_Characters",
        };
    };
};
class CfgVehicles
{
    class HighCapacityVest_ColorBase;
    class OF_Vest_Test: HighCapacityVest_ColorBase
    {
		scope=2;
        displayName ="Fluffie's Admin Vest";
        descriptionShort ="Cool Stuff";
        itemSize[] = {2,2};
		itemsCargoSize[] = {10.10};
		varWetMax=0.25;
        heatIsolation=1;
		attachments[] = {};
		hiddenSelections[] = 
		{
			"zbytek",
			"zbytek",
			"zbytek"
		};
        hiddenSelectionsTextures[] =
        {
            "Fluffie_Customs\Fluffies_Clothing\Vest\Fluffie_admin_Vest.paa",
            "Fluffie_Customs\Fluffies_Clothing\Vest\Fluffie_admin_Vest.paa",
            "Fluffie_Customs\Fluffies_Clothing\Vest\Fluffie_admin_Vest.paa"
        };
    };
};
