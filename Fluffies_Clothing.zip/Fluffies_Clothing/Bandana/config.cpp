class CfgPatches
{
    class Fluffie_Customs
    {
		units[]={};
        weapons[]={};
        requiredVersion=0.1;
        requiredAddons[]={
			"DZ_Data",
			"DZ_Characters",
        };
    };
};
class CfgVehicles
{
    class Bandana_ColorBase;
    class OF_Fluffies_Bandana: Bandana_ColorBase
    {
		scope=2;
        displayName ="Fluffie's Bandana";
        descriptionShort ="";
        itemSize[] = {2,2};
		itemsCargoSize[] = {};
		varWetMax=0.25;
        heatIsolation=1;
		attachments[] = {};
		hiddenSelections[] = 
		{
			"zbytek",
			"zbytek",
			"zbytek"
		};
        hiddenSelectionsTextures[] =
        {
            "Fluffie_Customs\Fluffies_Clothing\Bandana\fluffies_Bandana.paa",
            "Fluffie_Customs\Fluffies_Clothing\Bandana\fluffies_Bandana.paa",
            "Fluffie_Customs\Fluffies_Clothing\Bandana\fluffies_Bandana.paa"
        };
    };
};
