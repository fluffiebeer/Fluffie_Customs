class CfgPatches
{
    class Fluffie_Customs
    {
		units[]={};
        weapons[]={};
        requiredVersion=0.1;
        requiredAddons[]={
			"DZ_Data",
			"DZ_Characters",
        };
    };
};
class CfgVehicles
{
    class TTSKOPants;
    class OF_Fluffie_Pants: TTSKOPants
    {
		scope=2;
        displayName ="Fluffie's Admin Pants";
        descriptionShort ="";
        		itemSize[] = {2,2};
		itemsCargoSize[] = {10,15};
		varWetMax=0.25;
        heatIsolation=1;
		attachments[] = {"Knife"};
		hiddenSelections[] = 
		{
			"zbytek",
			"zbytek",
			"zbytek"
		};
        hiddenSelectionsTextures[] =
        {
            "Fluffie_Customs\Fluffies_Clothing\Pants\Fluffies_Pants.paa",
            "Fluffie_Customs\Fluffies_Clothing\Pants\Fluffies_Pants.paa",
            "Fluffie_Customs\Fluffies_Clothing\Pants\Fluffies_Pants.paa"
        };
    };
};
